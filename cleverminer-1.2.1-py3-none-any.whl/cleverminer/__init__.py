from cleverminer.cleverminer import cleverminer

# print disclaimer
print("Cleverminer version ", cleverminer._get_ver(cleverminer))

